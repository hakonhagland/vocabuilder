Keyboard shortcuts
==================

* Escape closes a window
* In the main window, use the first character in the button name
* In the window for choosing the test paramaters,
   * use ``R``, ``L``, ``1``, and ``2`` to select the different radio buttons
* For the other windows, hold down ALT and the press the
  first character in the button name. For example ALT+O to press the "Ok" button.
