Introduction
============

An effective way to learn a vocabulary of a foreign language is to create it gradually
and at the same time practice it using a
`spaced repetition <https://en.wikipedia.org/wiki/Spaced_repetition>`_ approach.

This app aims to help make your language learning experience fun and enjoyable.

Currently supported platforms are Linux, Windows, and MacOS.
