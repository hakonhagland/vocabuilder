Database
========

The local vocabulary databases are saved in sub directory ``vocabuilder`` inside the ``user_data_dir`` as defined by the
`platformdirs <https://pypi.org/project/platformdirs/>`_ package.

The file format is `CSV <https://docs.python.org/3/library/csv.html>`_.
A backup is also saved to the ``backup`` directory, as described in :doc:`backup`.
