.. vocabuilder documentation master file, created by
   sphinx-quickstart on Thu Jul 27 11:24:38 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to vocabuilder's documentation!
=======================================

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    introduction
    installation
    usage
    configuration
    shortcuts
    input
    database
    backup
    macos
    source
    firebase
    Development <development>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
