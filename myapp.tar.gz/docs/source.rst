Source code
===========

Documentation for the
`source code <https://github.com/hakonhagland/vocabuilder/blob/main/src/vocabuilder/vocabuilder.py>`_
of the main script.

Module ``vocabuilder.vocabuilder``
----------------------------------

.. automodule:: vocabuilder.vocabuilder
   :members:
   :undoc-members:
   :show-inheritance:
